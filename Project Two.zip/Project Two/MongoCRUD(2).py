from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, user, password, host='nv-desktop-services.apporto.com', port = 31947, db='AAC', col='animals'):
        
        """
        Initialize the AnimalShelter with connection details.
        
        :param user: Username for MongoDB authentication.
        :param password: Password for MongoDB authentication.
        :param host: MongoDB server host. Defaults to 'nv-desktop-services.apporto.com'.
        :param port: MongoDB server port. Defaults to 31947.
        :param db: Database name. Defaults to 'AAC'.
        :param col: Collection name. Defaults to 'animals'.
        """
        
        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (user,password,host,port))
        self.database = self.client[db]
        self.collection = self.database[col]
        
# Method to implement the C in CRUD.
    def create(self, data):
        # Insert document into the database
        if data is not None:
            try:
                # Insert docuemtn into the DB.
                self.collection.insert_one(data)
                # If successful, return True
                return True
            except Exception as e:
                # if unsuccessful, return False
                print(f"An error occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")
            
# Method to implement the R in CRUD.
    def read(self,criteria=None):
        # Query document(s) in the database
        if criteria is None:
            criteria = {}
          
        try:
            documents = self.collection.find(criteria)
            #Convert & return.
            return list(documents)
        except Exception as e:
            print(f"An error occurred: {e}")
            # If fail,return empty list.
            return []
        
# Method to implement the U in CRUD.
    def update(self, query, update_values):
        # Update document(s) in the database
        if query is None or update_values is None:
            raise ValueError("Query and update values cannot be None")
            
        try:
            result = self.collection.update_many(query, {'$set': update_values})
            # Return count of modified documents
            return result.modified_count
        except Exception as e:
            print(f"An error has occurred during update: {e}")
            # If update fails, return 0
            return 0
        
# Method to implement the D in CRUD.
    def delete(self, query):
        # Delete document(s) from the database
        if query is None:
            raise ValueError("Query cannot be None")
            
        try:
            result = self.collection.delete_many(query)
            # Return deleted document count
            return result.deleted_count
        except Exception as e:
            print(f"An error has occurred during delete: {e}")
            # If delete fails, return 0
            return 0